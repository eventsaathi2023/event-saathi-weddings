import React, { useState } from 'react';
import { COMPANY_DETAILS } from '../data/content';
import { PageSection } from '../types';
import { Phone, Menu, X, Calendar, Sparkles } from 'lucide-react';

interface NavbarProps {
  activeSection: PageSection;
  onNavigate: (section: PageSection) => void;
  onOpenBookingModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeSection,
  onNavigate,
  onOpenBookingModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { id: PageSection; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'services', label: 'Services' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'work', label: 'Our Work' },
    { id: 'contact', label: 'Contact Us' },
  ];

  const handleLinkClick = (section: PageSection) => {
    onNavigate(section);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-[#0d1219]/95 backdrop-blur-md border-b border-[#d4af37]/20 transition-all duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          {/* Zone 1: Single text element wordmark */}
          <button
            onClick={() => handleLinkClick('home')}
            className="text-left group cursor-pointer shrink-0 focus:outline-none"
            aria-label="Event Saathi Weddings Home"
          >
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#d4af37] transition-transform duration-300 group-hover:rotate-12" />
              <span className="font-cinzel text-xl sm:text-2xl font-bold tracking-wider text-white group-hover:text-[#f3e5ab] transition-colors whitespace-nowrap">
                Event Saathi Weddings
              </span>
            </div>
            <div className="text-[10px] tracking-widest text-[#d4af37]/80 uppercase pl-7 -mt-1 hidden sm:block">
              India Pvt. Ltd. · Dhanbad
            </div>
          </button>

          {/* Zone 2: 5-6 clean single-line text navigation links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-300">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`cursor-pointer whitespace-nowrap shrink-0 transition-colors py-1 relative ${
                    isActive
                      ? 'text-[#f3e5ab] font-semibold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-[#d4af37] to-[#f3e5ab] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            <a
              href={`tel:${COMPANY_DETAILS.phoneClean}`}
              className="hidden xl:flex items-center gap-2 text-xs text-slate-300 hover:text-[#d4af37] px-3 py-2 border border-slate-700/60 rounded-md transition-colors whitespace-nowrap"
            >
              <Phone className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>{COMPANY_DETAILS.phone}</span>
            </a>
            <button
              onClick={onOpenBookingModal}
              className="cursor-pointer px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#0d1219] bg-gradient-to-r from-[#f3e5ab] via-[#d4af37] to-[#c59b27] hover:brightness-110 rounded-md shadow-md transition-all whitespace-nowrap flex items-center gap-2"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Book Consultation</span>
            </button>
          </div>

          {/* Mobile menu trigger button */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={onOpenBookingModal}
              className="cursor-pointer px-2.5 py-1.5 text-[11px] font-semibold text-[#0d1219] bg-[#d4af37] rounded-md whitespace-nowrap"
            >
              Book
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0a0e14] border-b border-[#d4af37]/20 px-4 pt-2 pb-6 space-y-3">
          <div className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className={`text-left px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  activeSection === link.id
                    ? 'bg-[#d4af37]/15 text-[#f3e5ab]'
                    : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>
          <div className="pt-3 border-t border-slate-800 flex flex-col gap-2">
            <a
              href={`tel:${COMPANY_DETAILS.phoneClean}`}
              className="flex items-center justify-center gap-2 py-2 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-700 rounded-md"
            >
              <Phone className="w-4 h-4 text-[#d4af37]" />
              <span>Call: {COMPANY_DETAILS.phone}</span>
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBookingModal();
              }}
              className="w-full py-2.5 text-xs font-semibold text-[#0d1219] bg-gradient-to-r from-[#f3e5ab] to-[#d4af37] rounded-md uppercase tracking-wider text-center"
            >
              Book Free Consultation
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
