import React, { useState } from 'react';
import { PageSection } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutUs } from './components/AboutUs';
import { Services } from './components/Services';
import { BudgetCalculator } from './components/BudgetCalculator';
import { Gallery } from './components/Gallery';
import { OurWork } from './components/OurWork';
import { ContactUs } from './components/ContactUs';
import { Footer } from './components/Footer';
import { FloatingActions } from './components/FloatingActions';
import { BookingModal } from './components/BookingModal';

export default function App() {
  const [activeSection, setActiveSection] = useState<PageSection>('home');
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedServiceForModal, setSelectedServiceForModal] = useState<string | undefined>();

  const handleNavigate = (section: PageSection) => {
    setActiveSection(section);
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleOpenBookingModal = (serviceTitle?: string) => {
    setSelectedServiceForModal(serviceTitle);
    setIsBookingModalOpen(true);
  };

  const handleScrollToBudgetCalculator = () => {
    const el = document.getElementById('budget-calculator');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0e14] text-slate-100 font-sans-body selection:bg-[#d4af37] selection:text-[#0a0e14]">
      {/* Navigation Top Bar */}
      <Navbar
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenBookingModal={() => handleOpenBookingModal()}
      />

      {/* Main Page Flow */}
      <main>
        {/* 1. Hero Section */}
        <div id="home">
          <Hero
            onOpenBookingModal={() => handleOpenBookingModal()}
            onOpenBudgetCalculator={handleScrollToBudgetCalculator}
            onNavigateToGallery={() => handleNavigate('gallery')}
          />
        </div>

        {/* 2. About Us Section */}
        <div id="about">
          <AboutUs />
        </div>

        {/* 3. Services Section */}
        <div id="services">
          <Services
            onOpenBookingModalWithService={(serviceTitle) => handleOpenBookingModal(serviceTitle)}
          />
        </div>

        {/* 4. Interactive Budget & Guest Calculator */}
        <BudgetCalculator />

        {/* 5. Gallery Section */}
        <div id="gallery">
          <Gallery
            onPlanSimilarEvent={(eventName) =>
              handleOpenBookingModal(`Similar to: ${eventName}`)
            }
          />
        </div>

        {/* 6. Our Work & Case Studies */}
        <div id="work">
          <OurWork />
        </div>

        {/* 7. Contact Us Section */}
        <div id="contact">
          <ContactUs initialService={selectedServiceForModal} />
        </div>
      </main>

      {/* Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenBookingModal={() => handleOpenBookingModal()}
      />

      {/* Floating Call & WhatsApp Buttons */}
      <FloatingActions />

      {/* Global Booking Consultation Modal */}
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        selectedServiceTitle={selectedServiceForModal}
      />
    </div>
  );
}
